quiz-application
================

This is a quiz application based on python. This application requires graphical user interfaces like pygtk,tkinter,wxpython,pygt. This application contains an API which work on the above four mentioned graphical user interfaces.

USAGE:
To run quiz application in all toolkits,you must install all four toolkits. First run main.py using command python main.py,then select any option listed in it
